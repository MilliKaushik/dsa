package taskPlanner;

public enum TaskStatus {

	OPEN, IN_PROGRESS, COMPLETED, TESTING, DEPLOYED, FIXED
}
