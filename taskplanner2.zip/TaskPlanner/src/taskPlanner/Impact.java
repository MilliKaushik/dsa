package taskPlanner;

public enum Impact {
	LOW, MODERATE, HIGH
}
