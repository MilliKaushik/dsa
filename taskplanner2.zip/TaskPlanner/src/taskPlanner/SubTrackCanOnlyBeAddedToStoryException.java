package taskPlanner;

public class SubTrackCanOnlyBeAddedToStoryException extends Exception {

}
