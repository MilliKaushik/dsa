package taskPlanner;

public enum SubTrackStatus {

	OPEN, IN_PROGRESS, COMPLETED

}
