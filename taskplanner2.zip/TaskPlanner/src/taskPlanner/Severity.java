package taskPlanner;

public enum Severity {
	P0, P1, P2
}
