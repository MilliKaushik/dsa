package taskPlanner;

public enum SprintStatus {
	OPEN, IN_PROGRESS, COMPLETED
}
