package lockerManagementSystem;

public enum PackageSize {

	SMALL, MEDIUM, LARGE

}
