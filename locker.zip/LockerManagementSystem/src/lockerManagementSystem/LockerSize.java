package lockerManagementSystem;

public enum LockerSize {
	SMALL, MEDIUM, LARGE
}
