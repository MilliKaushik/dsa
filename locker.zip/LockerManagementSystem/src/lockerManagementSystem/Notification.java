package lockerManagementSystem;

public class Notification {

	private String message;

}
