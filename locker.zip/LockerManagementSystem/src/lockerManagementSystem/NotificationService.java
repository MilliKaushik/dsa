package lockerManagementSystem;

public class NotificationService {

	public void notify(Notification notification) {
		notifyCustomer();
		notifyDeliveryAgent();
	}

	private void notifyDeliveryAgent() {
		// TODO Auto-generated method stub
		
	}

	private void notifyCustomer() {
		// TODO Auto-generated method stub
		
	}

}
