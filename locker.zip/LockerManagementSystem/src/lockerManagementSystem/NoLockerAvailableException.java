package lockerManagementSystem;

public class NoLockerAvailableException extends Exception {

}
