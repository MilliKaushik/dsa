package lockerManagementSystem;

public class OrchestratorService {

	private LockerService lockerService;

	private NotificationService notificationService;
	
	private PackageService packageService;

	public void allocateLocker(AllocateLockerRequest allocateLockerRequest) {

		try {
			Booking booking = lockerService.allocateLocker(allocateLockerRequest);
		} catch (NoLockerAvailableException e) {
			e.printStackTrace();
		}

		Notification notification = new Notification();
		notificationService.notify(notification);

	}
	
	public void returnPackage(ReturnPackageRequest request) {
		packageService.returnPackage(request);
		

		Notification notification = new Notification();
		notificationService.notify(notification);


	}

}
