package lockerManagementSystem;

public class OTPGenerationService {
	
	
	public OTP generateOTP() {
		return null;		
	}

}
