package datastore;

public class Record {

}
