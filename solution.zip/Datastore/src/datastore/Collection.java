package datastore;

public class Collection {

}
