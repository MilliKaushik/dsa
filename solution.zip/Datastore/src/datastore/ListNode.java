package datastore;

public class ListNode {

	int data;
	ListNode next;

	public ListNode(int data) {
		this.data = data;
	}
}
