package datastore;

public class Database {

}
