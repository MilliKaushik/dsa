package datastore;

public class Test {

	public static void main(String[] args) {

		RemoveCharOcurrence removeChar = new RemoveCharOcurrence();
		System.out.println(removeChar.removeOccurence("abcda", 'a'));

		// ReverseLinkedList reverse = new ReverseLinkedList();

		// Test case 1 : empty list
		// reverse.reverseLinkedList(null);

//		// Test case 2 : single element
//		ListNode l1 = new ListNode(1);
//		reverse.reverseLinkedList(l1);
//		reverse.printList(l1);
//
//		// Test case 3 : 2 elements
//		ListNode l11 = new ListNode(1);
//		ListNode l21 = new ListNode(2);
//		l11.next = l21;
//		ListNode reversedHead = reverse.reverseLinkedList(l11);
//		reverse.printList(reversedHead);

		// Test case 4

		// Test case 3 : 2 elements
//		ListNode l1 = new ListNode(1);
//		ListNode l2 = new ListNode(2);
//		ListNode l3 = new ListNode(3);
//		ListNode l4 = new ListNode(4);
//		ListNode l5 = new ListNode(5);
//
//		l1.next = l2;
//		l2.next = l3;
//		l3.next = l4;
//		l4.next = l5;
//
//		ListNode reversedHead = reverse.reverseLinkedList(l1);
//		reverse.printList(reversedHead);

	}

}
