package taskPlanner;

public class TaskAssignedToOldSprintException extends Exception {

}
