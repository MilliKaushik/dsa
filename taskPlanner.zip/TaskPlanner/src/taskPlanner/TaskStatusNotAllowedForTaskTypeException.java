package taskPlanner;

public class TaskStatusNotAllowedForTaskTypeException extends Exception {

}
