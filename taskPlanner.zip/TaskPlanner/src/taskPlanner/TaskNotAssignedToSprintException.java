package taskPlanner;

public class TaskNotAssignedToSprintException extends Exception {

}
