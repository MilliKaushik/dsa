package taskPlanner;

public class Bug extends Task {

	private Severity severity;

	public Severity getSeverity() {
		return severity;
	}

	public void setSeverity(Severity severity) {
		this.severity = severity;
	}

}
