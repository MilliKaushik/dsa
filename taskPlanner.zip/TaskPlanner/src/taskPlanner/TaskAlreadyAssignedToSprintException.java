package taskPlanner;

public class TaskAlreadyAssignedToSprintException extends Exception {

}
