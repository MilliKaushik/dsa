package taskPlanner;

public enum TaskType {
	FEATURE, BUG, STORY
}
